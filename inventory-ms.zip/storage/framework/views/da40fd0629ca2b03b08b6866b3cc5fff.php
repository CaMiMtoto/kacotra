<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>KACOTRA Dashboard Inventory</title>

        <!-- Favicons -->
        <link href="<?php echo e(asset('assets/img/logos/cement-bag-01.png')); ?>" rel="icon">
        <link href="<?php echo e(asset('assets/img/logos/cement-bag-01.png')); ?>" rel="apple-touch-icon">

        <!-- Styles CSS -->
        <link href="<?php echo e(asset('assets/css/styles.css')); ?>" rel="stylesheet" />

        <!-- Icons -->
        <script data-search-pseudo-elements="" defer="" src="<?php echo e(asset('assets/js/font-awesome.all.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/feather-icons.min.js')); ?>"></script>

        <!-- Custom CSS for specific page.  -->
        <?php echo $__env->yieldContent('specificpagestyles'); ?>
    </head>

    <body class="nav-fixed">
        <!-- BEGIN: Navbar Brand -->
        <?php echo $__env->make('dashboard.body.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- END: Navbar Brand -->

        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <!-- BEGIN: Sidenav -->
                <?php echo $__env->make('dashboard.body.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- END: Sidenav -->
            </div>


            <div id="layoutSidenav_content">
                <main>
                <!-- BEGIN: Content -->
                    <?php echo $__env->yieldContent('content'); ?>
                <!-- END: Content -->
                </main>

                <!-- BEGIN: Footer  -->
                <?php echo $__env->make('dashboard.body.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- END: Footer  -->
            </div>
        </div>

        <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/scripts.js')); ?>"></script>

        <!-- Custom JS for specific page.  -->
        <?php echo $__env->yieldContent('specificpagescripts'); ?>
    </body>
</html>
<?php /**PATH C:\laragon\www\inventory-ms\resources\views/dashboard/body/main.blade.php ENDPATH**/ ?>