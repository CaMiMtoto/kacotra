<?php $__env->startSection('content'); ?>
<div class="container-xl px-4">
    <div class="row justify-content-center">
        <div class="col-xl-5 col-lg-5">
            <!-- BEGIN: Social Registration Form -->
            <div class="card my-2">
                <img src="<?php echo e(asset('assets/img/logos/kacotra-cement.png')); ?>" alt="KACOTRA Ltd" class="img-fluid mx-5" />
                <div class="card-body px-3 text-center">
                    <div class="h3 fw-light mb-0">Create an Account</div>
                </div>

                <hr class="my-0" />

                <div class="card-body px-3">
                    <!-- BEGIN: Login Form -->
                    <form action="<?php echo e(route('register')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <!-- Form Group (name) -->
                        <div class="mb-1">
                            <label class="text-gray-600 small" for="name">Full Name</label>
                            <input class="form-control form-control-solid <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" id="name" name="name" placeholder="" value="<?php echo e(old('name')); ?>" autocomplete="off"/>
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <i class="bx bx-radio-circle"></i>
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <!-- Form Group (usename) -->
                        <div class="mb-1">
                            <label class="text-gray-600 small" for="username">Username</label>
                            <input class="form-control form-control-solid <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" id="username" name="username" placeholder="" value="<?php echo e(old('username')); ?>" autocomplete="off"/>
                            <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <i class="bx bx-radio-circle"></i>
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <!-- Form Group (email address) -->
                        <div class="mb-1">
                            <label class="text-gray-600 small" for="email">Email Address</label>
                            <input class="form-control form-control-solid <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" id="email" name="email" placeholder=""  value="<?php echo e(old('email')); ?>" autocomplete="off"/>
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <i class="bx bx-radio-circle"></i>
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <!-- Form Row -->
                        <div class="row gx-3">
                            <div class="col-md-6">
                                <!-- Form Group (choose password) -->
                                <div class="mb-1">
                                    <label class="text-gray-600 small" for="password">Password</label>
                                    <input class="form-control form-control-solid <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="password" id="password" name="password" placeholder=""/>
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <i class="bx bx-radio-circle"></i>
                                        <?php echo e($message); ?>

                                    </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <!-- Form Group (confirm password) -->
                                <div class="mb-1">
                                    <label class="text-gray-600 small" for="password_confirmation">Confirm Password</label>
                                    <input class="form-control form-control-solid <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="password" id="password_confirmation" name="password_confirmation" placeholder=""/>
                                </div>
                            </div>
                        </div>
                        <!-- Form Group (form submission) -->
                        <div class="d-flex align-items-center justify-content-between">
                            <div class="form-check">
                                <input class="form-check-input" id="checkTerms" type="checkbox" value="" />
                                <label class="form-check-label" for="checkTerms">
                                    I accept the <a href="#">terms &amp; conditions</a>.
                                </label>
                            </div>
                            <button type="submit" class="btn btn-primary">Create Account</button>
                        </div>
                    </form>
                    <!-- END: Login Form -->
                </div>
                <hr class="my-0" />
                <div class="card-body px-3 py-4">
                    <div class="small text-center">
                        Have an account?
                        <a href="<?php echo e(route('login')); ?>">Sign in!</a>
                    </div>
                </div>
            </div>
            <!-- END: Social Registration Form -->
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.body.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\inventory-ms\resources\views/auth/register.blade.php ENDPATH**/ ?>