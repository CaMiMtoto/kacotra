<?php $__env->startSection('content'); ?>
<!-- BEGIN: Header -->
<header class="page-header page-header-dark bg-gradient-primary-to-secondary pb-10">
    <div class="container-xl px-4">
        <div class="page-header-content pt-4">
            <div class="row align-items-center justify-content-between">
                <div class="col-auto my-4">
                    <h1 class="page-header-title">
                        <div class="page-header-icon"><i class="fa-solid fa-clock"></i></div>
                        Complete Orders
                    </h1>
                </div>
                <div class="col-auto my-4">
                    <a href="<?php echo e(route('pos.index')); ?>" class="btn btn-primary add-list my-1"><i class="fa-solid fa-plus me-3"></i>Add</a>
                    <a href="<?php echo e(route('products.index')); ?>" class="btn btn-danger add-list my-1"><i class="fa-solid fa-trash me-3"></i>Clear Search</a>
                </div>
            </div>

            <nav class="mt-4 rounded" aria-label="breadcrumb">
                <ol class="breadcrumb px-3 py-2 rounded mb-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active">Complete Orders</li>
                </ol>
            </nav>
        </div>
    </div>

    <!-- BEGIN: Alert -->
    <div class="container-xl px-4 mt-n4">
        <?php if(session()->has('success')): ?>
        <div class="alert alert-success alert-icon" role="alert">
            <button class="btn-close" type="button" data-bs-dismiss="alert" aria-label="Close"></button>
            <div class="alert-icon-aside">
                <i class="far fa-flag"></i>
            </div>
            <div class="alert-icon-content">
                <?php echo e(session('success')); ?>

            </div>
        </div>
        <?php endif; ?>
    </div>
    <!-- END: Alert -->
</header>
<!-- END: Header -->

<!-- BEGIN: Main Page Content -->
<div class="container px-2 mt-n10">
    <div class="card mb-4">
        <div class="card-body">
            <div class="row mx-n4">
                <?php echo $__env->make('partials.list-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <hr>

                <div class="col-lg-12">
                    <div class="table-responsive">
                        <table class="table table-sm table-striped align-middle">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col">No.</th>
                                    <th scope="col">Invoice</th>
                                    <th scope="col"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('customer.name', 'name'));?></th>
                                    <th scope="col"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('order_date', 'Date'));?></th>
                                    <th scope="col">Payment</th>
                                    <th scope="col"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('total'));?></th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e((($orders->currentPage() * (request('row') ? request('row') : 10)) - (request('row') ? request('row') : 10)) + $loop->iteration); ?></th>
                                    <td><?php echo e($order->invoice_no); ?></td>
                                    <td><?php echo e($order->customer->name); ?></td>
                                    <td><?php echo e($order->order_date); ?></td>
                                    <td><?php echo e($order->payment_type); ?></td>
                                    <td><?php echo e($order->total); ?></td>
                                    <td>
                                        <span class="btn btn-success btn-sm text-uppercase"><?php echo e($order->order_status); ?></span>
                                    </td>
                                    <td>
                                        <div class="d-flex">
                                            <a href="<?php echo e(route('order.orderCompleteDetails', $order->id)); ?>" class="btn btn-outline-success btn-sm mx-1"><i class="fa-solid fa-eye"></i></a>
                                            <a href="<?php echo e(route('order.downloadInvoice', $order->id)); ?>" class="btn btn-outline-primary btn-sm mx-1"><i class="fa-solid fa-print"></i></a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <?php echo e($orders->links()); ?>

            </div>
        </div>
    </div>
</div>
<!-- END: Main Page Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.body.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\inventory-ms\resources\views/orders/complete-orders.blade.php ENDPATH**/ ?>