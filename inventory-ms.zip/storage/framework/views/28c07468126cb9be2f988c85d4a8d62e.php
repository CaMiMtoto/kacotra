<?php $__env->startSection('content'); ?>
<!-- BEGIN: Header -->
<header class="page-header page-header-dark bg-gradient-primary-to-secondary pb-10">
    <div class="container-xl px-4">
        <div class="page-header-content pt-4">
            <div class="row align-items-center justify-content-between">
                <div class="col-auto my-4">
                    <h1 class="page-header-title">
                        <div class="page-header-icon"><i class="fa-solid fa-cash-register"></i></div>
                        Order List
                    </h1>
                </div>
                <div class="col-auto my-4">
                    <a href="<?php echo e(route('orders.getOrderReport')); ?>" class="btn btn-success add-list my-1"><i class="fa-solid fa-file-export me-3"></i>Export</a>
                    <a href="<?php echo e(route('orders.createOrder')); ?>" class="btn btn-primary add-list my-1"><i class="fa-solid fa-plus me-3"></i>Add</a>
                    <a href="<?php echo e(route('orders.allOrders')); ?>" class="btn btn-danger add-list my-1"><i class="fa-solid fa-trash me-3"></i>Clear Search</a>
                </div>
            </div>

            <nav class="mt-4 rounded" aria-label="breadcrumb">
                <ol class="breadcrumb px-3 py-2 rounded mb-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active">All Orders</li>
                </ol>
            </nav>
        </div>
    </div>

    <!-- BEGIN: Alert -->
    <div class="container-xl px-4 mt-n4">
        <?php if(session()->has('success')): ?>
        <div class="alert alert-success alert-icon" role="alert">
            <button class="btn-close" type="button" data-bs-dismiss="alert" aria-label="Close"></button>
            <div class="alert-icon-aside">
                <i class="far fa-flag"></i>
            </div>
            <div class="alert-icon-content">
                <?php echo e(session('success')); ?>

            </div>
        </div>
        <?php endif; ?>
    </div>
    <!-- END: Alert -->
</header>
<!-- END: Header -->

<!-- BEGIN: Main Page Content -->
<div class="container px-2 mt-n10">
    <div class="card mb-4">
        <div class="card-body">
            <div class="row mx-n4">
                <?php echo $__env->make('partials.list-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <hr>

                <div class="col-lg-12">
                    <div class="table-responsive">
                                <div class="overflow-auto" style="min-height:200px;max-height:400px">
                        <table class="table table-sm table-striped align-middle">
                            <thead class="thead-light">
                                
                                <tr>
                                    <th scope="col">No.</th>
                                    <th scope="col">Invoice</th>
                                    <th scope="col">Customer</th>
                                    <th scope="col">Date</th>
                                    <th scope="col">Payment</th>
                                    <th scope="col">Total</th>
                                    <th scope="col">Paid</th>
                                    <th scope="col">Due</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e((($orders->currentPage() * (request('row') ? request('row') : 10)) - (request('row') ? request('row') : 10)) + $loop->iteration); ?></th>
                                        <td><?php echo e($order->invoice_no); ?></td>
                                        <td><?php echo e($order->customer); ?></td>
                                        <td><?php echo e($order->order_date); ?></td>
                                        <td><?php echo e($order->payment_type); ?></td>
                                        <td class="text-end"><?php echo e(number_format($order->total,0)); ?></td>
                                        <td class="text-end"><?php echo e(number_format($order->pay,0)); ?></td>
                                        <td class="text-end"><?php echo e(number_format($order->due,0)); ?></td>
                                        <td>
                                            <span class="btn
                                            <?php if($order->order_status == 'complete'): ?>
                                                btn-success
                                            <?php else: ?>
                                                btn-warning
                                            <?php endif; ?>  btn-sm text-uppercase">
                                            <?php if($order->order_status == 'complete' && $order->due < 0): ?>
                                            refund
                                            <?php else: ?>
                                            <?php echo e($order->order_status); ?>

                                            <?php endif; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="d-flex">
                                                <?php if($order->order_status == 'pending' && $order->is_confirmed == 1): ?>
                                                <a href="<?php echo e(route('order.dueOrderDetails', $order->id)); ?>" class="btn btn-outline-warning btn-sm mx-1"><i class="fa-solid fa-eye"></i></a>
                                                <?php elseif($order->order_status == 'complete' && $order->due < 0): ?>
                                                <a href="<?php echo e(route('order.refundOrderDetails', $order->id)); ?>" class="btn btn-outline-danger btn-sm mx-1"><i class="fa-solid fa-eye"></i></a>
                                                <?php elseif($order->order_status == 'refund' && $order->due < 0): ?>
                                                <a href="<?php echo e(route('order.refundOrderDetails', $order->id)); ?>" class="btn btn-outline-danger btn-sm mx-1"><i class="fa-solid fa-eye"></i></a>
                                                
                                                <?php elseif($order->order_status == 'pending' && $order->is_confirmed == 0 && auth()->user()->role == 'seller'): ?>
                                                
                                                <a href="<?php echo e(route('order.deleteOrder', $order->id)); ?>" class="btn btn-outline-danger btn-sm" onclick="return confirm('Are you sure you want to delete this record?')"><i class="far fa-trash-alt"></i></a>
                                                <?php else: ?>
                                                <a href="<?php echo e(route('order.orderCompleteDetails', $order->id)); ?>" class="btn btn-outline-success btn-sm mx-1"><i class="fa-solid fa-eye"></i></a>
                                                <?php endif; ?>
                                                <a href="<?php echo e(route('order.downloadInvoice', $order->id)); ?>" class="btn btn-outline-primary btn-sm mx-1"><i class="fa-solid fa-print"></i></a>
                                                
                                            </div>

                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                                </div>
                        <table class="table table-sm table-dark table-striped align-middle">
                            <tbody>
                                <tr>
                                    <th scope="row" colspan="6">Total Invoices</th>
                                    <td class="text-end"><?php echo e(number_format($totalInvoices,0)); ?></td>
                                    <td colspan="2"></td>
                                </tr>
                                <tr>
                                    <th scope="row" colspan="6">Total Tax</th>
                                    <td class="text-end"><?php echo e(number_format($totalTax,0)); ?></td>
                                    <td colspan="2"></td>
                                </tr>
                                <tr>
                                    <th scope="row" colspan="6">Total Paid in hand</th>
                                    <td class="text-end"><?php echo e(number_format($cashInHand,0)); ?></td>
                                    <td colspan="2"></td>
                                </tr>
                                <tr>
                                    <th scope="row" colspan="6">Total Paid Mobile Money</th>
                                    <td class="text-end"><?php echo e(number_format($cashMoMo,0)); ?></td>
                                    <td colspan="2"></td>
                                </tr>
                                <tr>
                                    <th scope="row" colspan="6">Total Paid with Cheque</th>
                                    <td class="text-end"><?php echo e(number_format($cashInCheque,0)); ?></td>
                                    <td colspan="2"></td>
                                </tr>
                                <tr>
                                    <th scope="row" colspan="6">Cash Due</th>
                                    <td class="text-end"><?php echo e(number_format($cashDue,0)); ?></td>
                                    <td colspan="2"></td>
                                </tr>
                                <tr>
                                    <th scope="row" colspan="6">Cash Over (to refund)</th>
                                    <td class="text-end"><?php echo e(number_format($cashOver,0)); ?></td>
                                    <td colspan="2"></td>
                                </tr>
                                <tr>
                                    <th scope="row" colspan="6">Total Paid</th>
                                    <td class="text-end"><?php echo e(number_format($totalPaid,0)); ?></td>
                                    <td colspan="2"></td>
                                </tr>
                                <tr>
                                    <th scope="row" colspan="6">Balance</th>
                                    <td class="text-end"><?php echo e(number_format($balance,0)); ?></td>
                                    <td colspan="2"></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php echo e($orders->links()); ?>

            </div>
        </div>
    </div>
</div>
<!-- END: Main Page Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.body.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\inventory-ms\resources\views/orders/orders.blade.php ENDPATH**/ ?>