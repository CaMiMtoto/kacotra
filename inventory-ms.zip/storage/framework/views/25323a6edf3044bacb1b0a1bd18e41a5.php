<?php $__env->startSection('content'); ?>
<div class="container-xl px-4">
    <div class="row justify-content-center">
        <div class="col-xl-5 col-lg-6 col-md-8 col-sm-11">
            <div class="card my-2">
                <img src="<?php echo e(asset('assets/img/logos/kacotra-cement-01.png')); ?>" alt="KACOTRA Ltd" class="img-fluid mx-5" />
                <div class="card-body px-3 text-center">
                    <div class="h3 fw-light mb-0">Sign In</div>
                </div>
                <hr class="my-0" />
                <div class="card-body px-3">
                    <!-- BEGIN: Login Form-->
                    <form action="<?php echo e(route('login')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <!-- Form Group (email address)-->
                        <div class="mb-1">
                            <label class="text-gray-600 small" for="input_type">Email / Username</label>
                            <input
                                class="form-control form-control-solid <?php if($errors->get('email') OR $errors->get('username')): ?> is-invalid <?php endif; ?>"
                                type="text"
                                id="input_type"
                                name="input_type"
                                placeholder=""
                                value="<?php echo e(old('input_type')); ?>"
                                autocomplete="off"
                            />
                            <?php if($errors->get('email') OR $errors->get('username')): ?>
                                <div class="invalid-feedback">
                                    Incorrect username or password.
                                </div>
                            <?php endif; ?>
                        </div>
                        <!-- Form Group (password)-->
                        <div class="mb-1">
                            <label class="text-gray-600 small" for="password">Password</label>
                            <input
                                class="form-control form-control-solid <?php if($errors->get('email') OR $errors->get('username')): ?> is-invalid <?php endif; ?> <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                type="password"
                                id="password" name="password"
                                placeholder=""
                            />
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <i class="bx bx-radio-circle"></i>
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <!-- Form Group (forgot password link)-->
                        <div class="mb-1"><a class="small" href="#">Forgot your password?</a></div>
                        <!-- Form Group (login box)-->
                        <div class="d-flex align-items-center justify-content-between mb-0">
                            <div class="form-check">
                                <input class="form-check-input" id="remember_me" name="remember" type="checkbox" />
                                <label class="form-check-label" for="remember_me">Remember me.</label>
                            </div>
                            <button type="submit" class="btn btn-primary">Login</button>
                        </div>
                    </form>
                    <!-- END: Login Form-->
                </div>
                <hr class="my-0" />
                <div class="card-body px-3 py-4">
                    <div class="small text-center">
                        New user?
                        <a href="<?php echo e(route('register')); ?>">Create an account!</a>
                    </div>
                </div>
            </div>
            <!-- END: Social Login Form-->
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.body.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\inventory-ms\resources\views/auth/login.blade.php ENDPATH**/ ?>