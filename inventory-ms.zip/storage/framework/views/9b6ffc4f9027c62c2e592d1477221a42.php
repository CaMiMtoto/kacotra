<!DOCTYPE html>
<html lang="en">
<head>
    <title>Inventory</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="UTF-8">

    <!-- External CSS libraries -->
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('assets/invoice/css/bootstrap.min.css')); ?>">
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('assets/invoice/fonts/font-awesome/css/font-awesome.min.css')); ?>">

    <!-- Google fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <!-- Custom Stylesheet -->
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('assets/invoice/css/style.css')); ?>">
</head>
<body>

<!-- BEGIN: Invoice -->
<div class="invoice-16 invoice-content">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="invoice-inner-9" id="invoice_wrapper">
                    <div class="invoice-top">
                        <div class="row">
                            <div class="col-lg-6 col-sm-6">
                                <div class="logo">
                                    <img src="<?php echo e(asset('assets/img/logos/kacotra.png')); ?>" alt="KACOTRA" />
                                    
                                </div>
                            </div>
                            <div class="col-lg-6 col-sm-6">
                                <div class="invoice">
                                    <h1>Invoice # <span><?php echo e($order->invoice_no); ?></span></h1>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="invoice-info">
                        <div class="row">
                            <div class="col-sm-6 mb-50">
                                <div class="invoice-number">
                                    <h4 class="inv-title-1">Invoice date:</h4>
                                    <p class="invo-addr-1">
                                        <?php echo e($order->order_date); ?>

                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6 mb-50">
                                <h4 class="inv-title-1">Customer</h4>
                                <p class="inv-from-1"><?php echo e($order->customer->name); ?></p>
                                <p class="inv-from-1"><?php echo e($order->customer->phone); ?></p>
                                <p class="inv-from-1"><?php echo e($order->customer->email); ?></p>
                                <p class="inv-from-2"><?php echo e($order->customer->address); ?></p>
                            </div>
                            <div class="col-sm-6 text-end mb-50">
                                <h4 class="inv-title-1">Store</h4>
                                <p class="inv-from-1">KACOTRA Ltd</p>
                                <p class="inv-from-1">+250 788 000 000</p>
                                <p class="inv-from-1">sales@kacotra.com</p>
                                <p class="inv-from-2">Gisenyi, Rubavu, Western Province</p>
                            </div>
                        </div>
                    </div>
                    <div class="order-summary">
                        <div class="table-outer">
                            <table class="default-table table-sm invoice-table">
                                <thead>
                                <tr>
                                    <th>Item</th>
                                    <th>Price</th>
                                    <th>Quantity</th>
                                    <th>Subtotal</th>
                                </tr>
                                </thead>

                                <tbody>
                                <?php $__currentLoopData = $orderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->product->product_name); ?></td>
                                    <td><?php echo e($item->unitcost); ?></td>
                                    <td><?php echo e($item->quantity); ?></td>
                                    <td><?php echo e($item->total); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td><strong>Subtotal</strong></td>
                                    <td></td>
                                    <td></td>
                                    <td><strong><?php echo e($order->sub_total); ?></strong></td>
                                </tr>
                                <tr>
                                    <td><strong>Tax</strong></td>
                                    <td></td>
                                    <td></td>
                                    <td><strong><?php echo e($order->vat); ?></strong></td>
                                </tr>
                                <tr>
                                    <td><strong>Total</strong></td>
                                    <td></td>
                                    <td></td>
                                    <td><strong><?php echo e($order->total); ?></strong></td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                    </div>
                </div>
                <div class="invoice-btn-section clearfix d-print-none">
                    <a href="javascript:window.print()" class="btn btn-lg btn-print">
                        <i class="fa fa-print"></i> Print Invoice
                    </a>
                    <a id="invoice_download_btn" class="btn btn-lg btn-download">
                        <i class="fa fa-download"></i> Download Invoice
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- END: Invoice -->

<script src="<?php echo e(asset('assets/invoice/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/invoice/js/jspdf.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/invoice/js/html2canvas.js')); ?>"></script>
<script src="<?php echo e(asset('assets/invoice/js/app.js')); ?>"></script>

</body>
</html>
<?php /**PATH C:\laragon\www\inventory-ms\resources\views/orders/print-invoice.blade.php ENDPATH**/ ?>