<?php $__env->startSection('content'); ?>
<!-- BEGIN: Header -->
<header class="page-header page-header-dark bg-gradient-primary-to-secondary pb-10">
    <div class="container-xl px-4">
        <div class="page-header-content pt-4">
            <div class="row align-items-center justify-content-between">
                <div class="col-auto mt-4">
                    <h1 class="page-header-title">
                        <div class="page-header-icon"><i class="fa-solid fa-boxes-stacked"></i></div>
                        Details Issue
                    </h1>
                </div>
            </div>

            <nav class="mt-4 rounded" aria-label="breadcrumb">
                <ol class="breadcrumb px-3 py-2 rounded mb-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('issues.index')); ?>">Issues</a></li>
                    <li class="breadcrumb-item active">Details</li>
                </ol>
            </nav>
        </div>
    </div>
</header>
<!-- END: Header -->

<!-- BEGIN: Main Page Content -->
<div class="container-xl px-2 mt-n10">
        <div class="row">
            

            <div class="col-xl-8">
                <!-- BEGIN: Issue Code -->
                <div class="card mb-4">
                    <div class="card-header">
                        Issue Code
                    </div>
                    <div class="card-body">
                        <!-- Form Row -->
                        <div class="row gx-3 mb-3">
                            <!-- Form Group (type of issue department) -->
                            <div class="col-md-6">
                                <label class="small mb-1">Issue code</label>
                                <div class="form-control form-control-solid"><?php echo e($issue->issue_code); ?></div>
                            </div>
                            <!-- Form Group (type of issue unit) -->
                            
                        </div>
                    </div>
                </div>
                <!-- END: Issue Code -->

                <!-- BEGIN: Issue Information -->
                <div class="card mb-4">
                    <div class="card-header">
                        Issue Information
                    </div>
                    <div class="card-body">
                        <!-- Form Group (issue name) -->
                        <div class="mb-3">
                            <label class="small mb-1">Issue name</label>
                            <div class="form-control form-control-solid"><?php echo e($issue->issue_name); ?></div>
                        </div>
                        <!-- Form Row -->
                        <div class="row gx-3 mb-3">
                            <!-- Form Group (type of issue department) -->
                            <div class="col-md-6">
                                <label class="small mb-1">Issue department</label>
                                <div class="form-control form-control-solid"><?php echo e($issue->department->name); ?></div>
                            </div>
                            <!-- Form Group (type of issue unit) -->
                            <div class="col-md-6">
                                <label class="small mb-1">Issue unit</label>
                                <div class="form-control form-control-solid"><?php echo e($issue->unit->name); ?></div>
                            </div>
                        </div>
                        <!-- Form Row -->
                        <div class="row gx-3 mb-3">
                            <!-- Form Group (buying price) -->
                            <div class="col-md-6">
                                <label class="small mb-1">Buying price</label>
                                <div class="form-control form-control-solid"><?php echo e($issue->cost); ?></div>
                            </div>
                            <!-- Form Group (selling price) -->
                            
                        </div>
                        <!-- Form Group (occurence) -->
                        <div class="mb-3">
                            <label class="small mb-1">Occurence</label>
                            <div class="form-control form-control-solid"><?php echo e($issue->occurence); ?></div>
                        </div>

                        <!-- Submit button -->
                        <a class="btn btn-primary" href="<?php echo e(route('issues.index')); ?>">Back</a>
                    </div>
                </div>
                <!-- END: Issue Information -->
            </div>
        </div>
    </form>
</div>
<!-- END: Main Page Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.body.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\inventory-ms\resources\views/issues/show.blade.php ENDPATH**/ ?>