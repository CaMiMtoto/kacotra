<?php $__env->startSection('content'); ?>
<!-- BEGIN: Header -->
<header class="page-header page-header-dark bg-gradient-primary-to-secondary pb-10">
    <div class="container-xl px-4">
        <div class="page-header-content pt-4">
            <div class="row align-items-center justify-content-between">
                <div class="col-auto my-4">
                    <h1 class="page-header-title">
                        <div class="page-header-icon"><i class="fa-solid fa-boxes-stacked"></i></div>
                        <?php echo e($title); ?>

                    </h1>
                </div>
                <div class="col-auto my-4">
                    <a href="<?php echo e(route('products.import')); ?>" class="btn btn-success add-list my-1"><i class="fa-solid fa-file-import me-3"></i>Import</a>
                    <a href="<?php echo e(route('products.export')); ?>" class="btn btn-warning add-list my-1"><i class="fa-solid fa-file-arrow-down me-3"></i>Export</a>
                    <a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary add-list my-1"><i class="fa-solid fa-plus me-3"></i>Add</a>
                    <a href="<?php echo e(route('products.index')); ?>" class="btn btn-danger add-list my-1"><i class="fa-solid fa-trash me-3"></i>Clear Search</a>
                </div>
            </div>

            
        </div>
    </div>

    <!-- BEGIN: Alert -->
    <div class="container-xl px-4 mt-n4">
        <?php if(session()->has('success')): ?>
        <div class="alert alert-success alert-icon" role="alert">
            <button class="btn-close" type="button" data-bs-dismiss="alert" aria-label="Close"></button>
            <div class="alert-icon-aside">
                <i class="far fa-flag"></i>
            </div>
            <div class="alert-icon-content">
                <?php echo e(session('success')); ?>

            </div>
        </div>
        <?php endif; ?>
    </div>
    <!-- END: Alert -->
</header>
<!-- END: Header -->


<!-- BEGIN: Main Page Content -->
<div class="container px-2 mt-n10">
    <div class="card mb-4">
        <div class="card-body">
            <div class="row mx-n4">
                

                <?php echo $__env->make('partials.cashflow-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <hr>

                <div class="col-lg-12">
                    <div class="table-responsive">
                        <table class="table table-sm table-striped align-middle">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col">No.</th>
                                    
                                    <th scope="col">Description</th>
                                    <th scope="col">Details</th>
                                    <th scope="col">Amount</th>
                                </tr>
                                <tr>
                                    <th scope="col" colspan="4">Sales</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e((($sales->currentPage() * (request('row') ? request('row') : 10)) - (request('row') ? request('row') : 10)) + $loop->iteration); ?></th>
                                    <td><?php echo e($sale->p_name); ?></td>
                                    <td class="text-center">Qty: <?php echo e(number_format($sale->p_quantity)); ?></td>
                                    <td class="text-end"><?php echo e(number_format($sale->p_sales)); ?> RwF</td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row" colspan="3">Total Paid</th>
                                    <td class="text-end text-success"><?php echo e(number_format($total_paid)); ?> RwF</td>
                                </tr>
                                <tr>
                                    <th scope="row" colspan="3">Total Due</th>
                                    <td class="text-end text-danger"><?php echo e(number_format($total_due)); ?> RwF</td>
                                </tr>
                                <tr>
                                    <th scope="row" colspan="3">Total Excess</th>
                                    <td class="text-end text-primary"><?php echo e(number_format($total_refund)); ?> RwF</td>
                                </tr>
                                <tr>
                                    <th scope="row" colspan="3">Sub Total 1 (Sales value)</th>
                                    <td class="text-end"><?php echo e(number_format($subTotal1)); ?> RwF</td>
                                </tr>

                            </tbody>
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col" colspan="4">Purchases</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e((($purchases->currentPage() * (request('row') ? request('row') : 10)) - (request('row') ? request('row') : 10)) + $loop->iteration); ?></th>
                                    <td><?php echo e($purchase->pur_name); ?></td>
                                    <td class="text-center">Qty: <?php echo e(number_format($purchase->pur_quantity)); ?></td>
                                    <td class="text-end"><?php echo e(number_format($purchase->pur_total)); ?> RwF</td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row" colspan="3">Sub Total 2</th>
                                    <td class="text-end"><?php echo e(number_format($subTotal2)); ?> RwF</td>
                                </tr>

                            </tbody>
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col" colspan="4">Expenses</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e((($expenses->currentPage() * (request('row') ? request('row') : 10)) - (request('row') ? request('row') : 10)) + $loop->iteration); ?></th>
                                    <td><?php echo e($expense->exp_name); ?></td>
                                    <td class="text-center">Freq: <?php echo e(number_format($expense->exp_quantity)); ?></td>
                                    <td class="text-end"><?php echo e(number_format($expense->exp_total)); ?> RwF</td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row" colspan="3">Sub Total 3</th>
                                    <td class="text-end"><?php echo e(number_format($subTotal3)); ?> RwF</td>
                                </tr>

                            </tbody>
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col" colspan="4">Deposits</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e((($deposits->currentPage() * (request('row') ? request('row') : 10)) - (request('row') ? request('row') : 10)) + $loop->iteration); ?></th>
                                    <td><?php echo e($deposit->dep_code); ?></td>
                                    <td class="text-center">Bank: <?php echo e($deposit->dep_name); ?></td>
                                    <td class="text-end"><?php echo e(number_format($deposit->dep_total)); ?> RwF</td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row" colspan="3">Sub Total 4</th>
                                    <td class="text-end"><?php echo e(number_format($subTotal4)); ?> RwF</td>
                                </tr>

                            </tbody>
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col" colspan="4">Damages</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $damages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $damage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e((($damages->currentPage() * (request('row') ? request('row') : 10)) - (request('row') ? request('row') : 10)) + $loop->iteration); ?></th>
                                    <td><?php echo e($damage->dam_name); ?></td>
                                    <td class="text-center">Qty: <?php echo e(number_format($damage->dam_quantity)); ?></td>
                                    <td class="text-end"><?php echo e(number_format($damage->dam_total)); ?> RwF</td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr class="bg-warning">
                                    <th scope="row" colspan="3">Sub Total 5</th>
                                    <td class="text-end"><?php echo e(number_format($subTotal5)); ?> RwF</td>
                                </tr>

                            </tbody>
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col" colspan="4">Recoveries</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $recoveries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recovery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e((($recoveries->currentPage() * (request('row') ? request('row') : 10)) - (request('row') ? request('row') : 10)) + $loop->iteration); ?></th>
                                    <td><?php echo e($recovery->rec_invoice); ?> <span class="text-sm fw-lighter fst-italic">(<?php echo e($recovery->rec_customer); ?>)</span></td>
                                    <td class="text-center">Method: <?php echo e($recovery->rec_pay_type); ?></td>
                                    <td class="text-end"><?php echo e(number_format($recovery->rec_total)); ?> RwF</td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row" colspan="3">Sub Total 6</th>
                                    <td class="text-end"><?php echo e(number_format($subTotal6)); ?> RwF</td>
                                </tr>

                            </tbody>
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col" colspan="4">Refunds</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $refunds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $refund): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e((($refunds->currentPage() * (request('row') ? request('row') : 10)) - (request('row') ? request('row') : 10)) + $loop->iteration); ?></th>
                                    <td><?php echo e($refund->ref_invoice); ?> <span class="text-sm fw-lighter fst-italic">(<?php echo e($refund->ref_customer); ?>)</span></td>
                                    <td class="text-center">Method: <?php echo e($refund->ref_pay_type); ?></td>
                                    <td class="text-end"><?php echo e(number_format($refund->ref_total)); ?> RwF</td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row" colspan="3">Sub Total 7</th>
                                    <td class="text-end"><?php echo e(number_format($subTotal7)); ?> RwF</td>
                                </tr>
                            </tbody>
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col" colspan="4">Dues</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $dues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $due): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e((($dues->currentPage() * (request('row') ? request('row') : 10)) - (request('row') ? request('row') : 10)) + $loop->iteration); ?></th>
                                    <td><?php echo e($due->due_invoice); ?> <span class="text-sm fw-lighter fst-italic">(<?php echo e($due->due_customer ?? null); ?>)</span></td>
                                    <td class="text-center"><?php echo e($due->due_comment); ?> </td>
                                    <td class="text-end"><?php echo e(number_format($due->due_total)); ?> RwF</td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row" colspan="3">Sub Total 8</th>
                                    <td class="text-end"><?php echo e(number_format($subTotal8)); ?> RwF</td>
                                </tr>
                                <tr>
                                    <th scope="row" colspan="3">Balance <span class="text-sm fw-lighter fst-italic">(Sales - (Expenses + Deposits + Refunds) + Recoveries)</span></th>
                                    <td class="text-end fw-bolder <?php if($total < 0): ?> text-danger <?php endif; ?>"><?php echo e(number_format($total)); ?> RwF</td>
                                </tr>

                            </tbody>
                        </table>
                    </div>
                </div>

                
            </div>

        </div>
    </div>
</div>
<!-- END: Main Page Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.body.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\inventory-ms\resources\views/products/cashflow.blade.php ENDPATH**/ ?>